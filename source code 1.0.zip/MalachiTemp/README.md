# MalachiTemp
Hello, thx for choosing MalachiTemp, this template has everything you need to become a gtag
mod menu maker. it has some premade mods and settings, 10 different categorys, and a built in
gui

if you havent already, pls join the discord
https://discord.gg/Y3wuBxRBEW

and sub to me on yt at:
Malachi_the_modder

if you have any questions pls join the server and ping me (Malachi)

(not important stuff)
PROTECTION NOTE: THIS TEMPLATE IS PROTECTED MATERIAL FROM "Project Malachi". 
IF ANY MATERIAL FROM "MalachiTemp" FOUND IN ANY OTHER PROJECT/THING WITHOUT 
CREDIT OR PERMISSION MUST AND WILL BE REMOVED IMMEDIATELY